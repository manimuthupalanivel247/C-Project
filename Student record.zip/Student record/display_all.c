#include"student_header.h"

void display_all(st*ptr)
{
     printf("-----name list-----\n");
     printf("Roll\t\t\t Name\t\t\t marks\t\t\n");
    while(ptr!=NULL)
    {
        printf("%d\t\t\t %s\t\t\t %f\t\t\t\n",ptr->roll,ptr->name,ptr->marks);
        ptr = ptr->next;
    }
}
