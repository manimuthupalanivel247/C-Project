#include"student_header.h"

void modify(st**ptr)
{
int op;
do
{
  printf("Which data to be modified? 1) Name 2) Percentage 3) Exit\n");
  scanf("%d", &op);


switch(op)
{
case 1: {printf("Enter name\n");scanf(" %[^\n]",(*ptr)->name); break;}
case 2: {printf("Enter percentage\n");scanf("%f",&((*ptr)->marks)); break;}
case 3: {
          printf("-------Modified Data--------\n");
          printf("Roll\t\t\t Name\t\t\t marks\t\t\n");
          printf("%d\t\t\t",(*ptr)->roll);
          printf("%s\t\t\t",(*ptr)->name);
          printf("%f\t\t\t\n",(*ptr)->marks);
          return;
        }
default : {printf("Invalid option");break;}
}
}while(op!=3);



}