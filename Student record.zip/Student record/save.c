#include"student_header.h"

void save(st*ptr)
{
FILE*fp = fopen("data.csv","w");
fprintf(fp,"roll Name Marks\n");
if(ptr != NULL)
{
    while(ptr != NULL)
    {
    fprintf(fp,"%d %s %f\n",ptr->roll,ptr->name,ptr->marks);
    ptr = ptr->next;
    }
}
fclose(fp);


}