#include"student_header.h"

int main()
{
    int op;
    st*hptr=NULL;
    st*hptr_copy = NULL;
    do
    {
        printf("Enter option 1) Add_detail 2) Display 3) Sort 4) Modify 5) Save 6)Exit\t Note : Only allowed to give 1 to 6\n");
        scanf("%d",&op);
       
        switch(op)
        {
            case 1: 
            {
                {
                    int add_op;

                    do
                    {
                       if (op=='n') break; 
                       Add_detail(&hptr);
                                           
                       printf("Do you want to add more detail? y/n\n"); scanf(" %c",&add_op);                   
                    }while(add_op=='y');

                }
                
                break;
            }
            case 2: 
            {
               
                printf("%p\n",hptr_copy);
                printf("%p\n",hptr);
                printf("Original Database\n");
                display_all(hptr);
                printf("Modified Database\n");
                display_all(hptr_copy);
                break;
            }
            case 3: 
            {
                int sort_op;
                sort_option: printf("sort by 1)Name 2)Roll_no 3) Marks\n  Note : Only allowed to give 1 to 3\n");
                scanf("%d",&sort_op);
                if ((sort_op <=3) && (sort_op>=1)) 
                {
                    if (hptr_copy == hptr ) hptr_copy ==NULL;
                        copy_data(&hptr,&hptr_copy);
                        sort(&hptr_copy,sort_op);
                }

                else {printf("Enter valid option\n"); goto sort_option;}
                break;
            }
            case 4: 
            {
                int op;
                modify_option: printf("Category to be searched 1) Name 2) Roll\t Note : Only allowed to give 1 to 2\n");  
                scanf("%d", &op); 

                 if (hptr_copy == hptr ) hptr_copy ==NULL;
                 copy_data(&hptr,&hptr_copy);
                
                if(op==1) {find_name(&hptr_copy);}
                else if(op==2) {find_roll(&hptr_copy);}
                else {printf("Invalid option");goto modify_option;}

                break;
            }
            case 5: 
            {
                if (hptr_copy != NULL) hptr = hptr_copy;
                save(hptr);
               
               
               break;
            }
            case 6: 
            {
               return 0;
            }
            default : 
            {
                printf("Invalid, try again\n");
                break;
            }
        } //Switch end
        
        
    }while(op!=6);
    

}





