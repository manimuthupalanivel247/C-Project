#include"student_header.h"
static int rollno; 



void Add_detail(st**ptr)
{
    st*new = (st*)(malloc(sizeof(st)));
    new->next = NULL;
    new->roll = ++rollno;
    printf("Enter the name\n"); scanf(" %[^\n]",new->name);
    printf("Enter the marks\n"); scanf(" %f",&new->marks);
    
    st*temp = *ptr;
    if (*ptr == NULL) *ptr = new;
    else
    {
        while(temp->next != NULL) temp = temp->next;
        temp->next = new;
    }
}