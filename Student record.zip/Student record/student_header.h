#include<stdio.h>
#include<stdlib.h>
#include<string.h>


typedef struct student
{
    int roll;
    char name [20];
    float marks;
    struct student* next;
}st;

void sort(st**,int);
void display_all(st*);
void save(st*);
void Add_detail(st**);
void modify(st**);
void find_name(st**);
void find_roll(st**);
void copy_data(st**,st**);