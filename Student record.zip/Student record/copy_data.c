#include"student_header.h"

void copy_data(st**ptr,st**hptr_copy)
{
 st*temp_ptr = *ptr;   
 *hptr_copy = NULL;
while(temp_ptr != NULL )
{
    
   if (*hptr_copy == NULL)    
    {
        st*copy_node= (st*)(malloc(sizeof(st)));
        copy_node->roll = (*ptr) ->roll;
        strcpy(copy_node->name,(*ptr)->name);
        copy_node->marks = (*ptr)->marks;
        copy_node->next = NULL;

        *hptr_copy = copy_node;
        
    }
   else
    {
        
        st*new_copy_node= (st*)(malloc(sizeof(st)));
        st*temp_copy = *hptr_copy;
        
        new_copy_node->roll = temp_ptr->roll;
        strcpy(new_copy_node->name,temp_ptr->name);
        new_copy_node->marks = temp_ptr->marks;
        new_copy_node->next = NULL;

       
        while(temp_copy->next != NULL) {temp_copy = temp_copy->next;  }
        
        temp_copy->next = new_copy_node;
        
    }
    temp_ptr = temp_ptr->next;
}

}
      