#include"student_header.h"

void find_roll(st**ptr)
{
int roll_find,found_count=0;
st* temp = *ptr;
st* f_temp=NULL;
printf("Enter roll no\n"); 
scanf("%d", &roll_find);

printf("Roll\t\t\t Name\t\t\t marks\t\t\n");
while(temp != NULL )
{
    
    if(temp->roll == roll_find) 
    {
     printf("%d\t\t\t %s\t\t\t %f\t\t\t\n",temp->roll,temp->name,temp->marks);
     f_temp = temp; found_count++;
     break;
    }
    temp = temp->next;
}
if (found_count == 0) printf("No data found\n");
else if (found_count >1 ) printf("No similar roll no allowed, modify with unique roll no\n");
else modify(&f_temp);
}