#include"student_header.h"

void sort(st**ptr,int op)
{

    int count = 0;
    st* temp = *ptr;
     while(temp!=NULL)
    {
        count++;
        temp = temp->next;
    }

char t_name[20];
float temp_marks;
int temp_roll;


for(int i = 0; i < count-1 ; i++)
{
    temp = *ptr;
    for (int j =0; j<count-i-1; j++)
    {
        if(temp->next != NULL && temp != NULL)
        {
            switch(op)
            {
            case 1:
            {
            if((strcmp(temp->name,temp->next->name)) > 0) 
            {
             strcpy(t_name,temp->next->name);
             temp_marks = temp->next->marks;
             temp_roll = temp->next->roll;

             strcpy(temp->next-> name,temp->name);
             temp->next->marks = temp->marks;
             temp->next->roll = temp->roll;

             strcpy(temp->name,t_name);
             temp->marks = temp_marks;
             temp->roll = temp_roll;
            }
            temp = temp->next;
            break;
            }
            case 2:
            {
            if(temp->roll > temp->next->roll) 
            {
             strcpy(t_name,temp->next->name);
             temp_marks = temp->next->marks;
             temp_roll = temp->next->roll;

             strcpy(temp->next-> name,temp->name);
             temp->next->marks = temp->marks;
             temp->next->roll = temp->roll;

             strcpy(temp->name,t_name);
             temp->marks = temp_marks;
             temp->roll = temp_roll;
            }
            
            temp = temp->next;
            break;
            }
            case 3:
            {
            if(temp->marks > temp->next->marks) 
            {
             strcpy(t_name,temp->next->name);
             temp_marks = temp->next->marks;
             temp_roll = temp->next->roll;

             strcpy(temp->next-> name,temp->name);
             temp->next->marks = temp->marks;
             temp->next->roll = temp->roll;

             strcpy(temp->name,t_name);
             temp->marks = temp_marks;
             temp->roll = temp_roll;
            }
            temp = temp->next;
            break;
            }
            default : {printf("Invalid option, try again\n"); break;}
            }


        }
    }
}
display_all(*ptr);

}

