#include"student_header.h"


void find_name(st**ptr)
{
int found_count;
char name[20]; 
st* temp = *ptr;
st* f_temp=NULL;
printf("Enter name\n"); scanf(" %[^\n]",name);
printf("Roll\t\t\t Name\t\t\t marks\t\t\n");
while(temp != NULL)
{
    if((strcmp(temp->name,name)) == 0) 
    {
        printf("%d\t\t\t %s\t\t\t %f\t\t\t\n",temp->roll,temp->name,temp->marks);
        found_count++;
        f_temp = temp;
    }
    temp = temp->next;
}

if (found_count > 1) 
{
    find_roll(ptr);
}

else if (found_count == 0)  printf("No data available\n"); 

else modify(&f_temp);

}