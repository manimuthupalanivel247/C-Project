#include "LMS.h"

char* time_stamp(int day_count)
{    
    time_t time_val;
    time(&(time_val));
    time_val += day_count*60*60*24;
    printf("%d\n",time_val);
    static char buffer[20];
    struct tm *time_info = localtime(&time_val);
    strftime(buffer,sizeof(buffer),"%d-%m-%Y %H:%M:%S", time_info);   
    return buffer;
}