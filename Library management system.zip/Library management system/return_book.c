#include "LMS.h"

void return_book(st**ptr)
{

    if (((*ptr)->Book_status,"Book issued")==0)
    {
    ++((*ptr)->Quantity);

    strcpy(((*ptr)->Return_date),time_stamp(0));

    //stored due date string    
    const char *due_date_str = (*ptr)->Due_date; 
    int fine_per_day = 5; 
    
    // 1. Extract the date from the string
    struct tm due_tm = {0};
    int d, m, y, h, min, s;
    sscanf(due_date_str, "%d-%d-%d %d:%d:%d", &d, &m, &y, &h, &min, &s);

    due_tm.tm_mday = d;
    due_tm.tm_mon  = m - 1;     // C months are 0-11
    due_tm.tm_year = y - 1900;  // C years are since 1900
    due_tm.tm_hour = h;
    due_tm.tm_min  = min;
    due_tm.tm_sec  = s;
   
   // 2. Convert string data to raw seconds
    time_t due_date = mktime(&due_tm);
    
    // 3. Get current return time
    time_t current_time;
    time(&current_time);

    // 4. Calculate difference and fine
    double diff_seconds = difftime(current_time, due_date);
    (*ptr) -> overdue_days = diff_seconds / 86400; // 86400 seconds in a day

    if ((*ptr) -> overdue_days > 0)  (*ptr) -> fine_amount = ((*ptr) -> overdue_days)*fine_per_day;
    else (*ptr) -> fine_amount = 0;
    
    strcpy((*ptr)->Book_status ,"Book returned");
    return;
    }
    else
    {
        printf("Book not issued\n");
        return;
    }
}
