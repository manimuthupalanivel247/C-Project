#include "LMS.h"
void Add_New_Book(st**ptr)
{
    st*new = (st*)(malloc(sizeof(st)));
    new->next = NULL;
    printf("Enter the Book ID\n"); scanf(" %[^\n]",new->Book_ID);
    printf("Enter the Title\n"); scanf(" %[^\n]",new->Title);
    printf("Enter the Author\n"); scanf(" %[^\n]",new->Author);
    printf("Enter the Quantity\n"); scanf("%d",&new->Quantity);
    strcpy(new->User_ID,"Nil");
    strcpy(new->User_name,"Nil");
    strcpy(new->Issue_date,"Nil");
    strcpy(new->Due_date,"Nil");
    strcpy(new->Return_date,"Nil");
    strcpy(new->Book_status,"Nil");
    new->overdue_days=0;
    new->fine_amount=0;

      
    st*temp = *ptr;
    if (*ptr == NULL) *ptr = new;
    else
    {
        while(temp->next != NULL) temp = temp->next;
        temp->next = new;
    }
    return;
}