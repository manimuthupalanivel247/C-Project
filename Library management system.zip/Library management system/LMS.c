#include "LMS.h"

int main()
{
    int op;
    st*hptr=NULL;
    login();
    copy_data(&hptr);
    
    do
    {
        printf("Enter option 1) Add_New_Book 2) Display 3) Issue_book 4) Return Book 5) Update Book Details  6) Save 7)Search  8)Exit  \t Note : Only allowed to give 1 to 6\n");
        
        if (scanf("%d", &op) != 1) 
        {
            // If it failed, clear the garbage characters from the buffer
            while (getchar() != '\n'); 
            op = -1; // Force an invalid option to trigger the default case safely
        }
        
       
        switch(op)
        {
            case 1: 
            {
                {
                    char add_op;
                    do
                    {
                       Add_New_Book(&hptr);
                       pf
                       printf("Do you want to add more detail? y/n\n"); scanf(" %c",&add_op);                   
                    }while(add_op=='y');
                }
                
                break;
            }
            case 2: 
            {
                printf("%p\n",hptr);
                display_all(hptr);
                break;
            }
            case 3: 
            {
                st*issue_ptr = search(hptr);
                issue_book(&issue_ptr);
                save(hptr);
                break;
            }
            case 4: 
            {
                st*return_ptr = search(hptr);
                return_book(&return_ptr);
                save(hptr);
                break;
            }
            case 5: 
            {
                st*mod_ptr = search(hptr);  
                modify(&mod_ptr);
                break;
            }
            case 6: 
            {
                save(hptr);
                break;
            }
            
            case 7: 
            {
                search(hptr);
                break;
               
            }
            case 8 :
            {
               return 0;
            }
            default : 
            {
                printf("Invalid, try again\n");
                break;
                
            }
        } //Switch end
        
        
    }while(op<=9);
    

}





