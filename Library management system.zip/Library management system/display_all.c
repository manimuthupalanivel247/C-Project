#include "LMS.h"

void display_all(st*ptr)
{
     printf("-----Book list-----\n");
     printf("Book ID\t\t\t Title\t\t\t Author\t\tQuantity\t\tUser_ID\t\tUser_name\t\tIssue_date\t\tDue_date\t\tReturn_date\t\t\tBook_status\t\toverdue_days\t\tfine_amount\n");
    while(ptr!=NULL)
    {
        printf("%s\t\t %s\t\t %s\t\t%d\t\t %s\t\t %s\t\t%s\t\t %s\t\t %s\t\t%s\t\t %d\t\t %d\t\t\n",ptr->Book_ID,ptr->Title,ptr->Author,ptr->Quantity,ptr->User_ID,ptr->User_name,
            ptr->Issue_date,ptr->Due_date,ptr->Return_date,ptr->Book_status,ptr->overdue_days,ptr->fine_amount);
        ptr = ptr->next;
    }
}

