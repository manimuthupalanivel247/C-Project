#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>

typedef struct lms
{
    char Book_ID [20];
    char Title [20];
    char Author [20];
    int Quantity;
    char User_ID [20];
    char User_name [20];
    char Issue_date[20];
    char Due_date[20];
    char Return_date[20];
    char Book_status[20];
    int overdue_days;
    int fine_amount;
    struct lms* next;
}st;

# define pf printf("I am here\n");

void Add_New_Book(st**);
void signup(void);
void login(void);



void display_all(st*);
void save(st*);
void modify(st**);
char* time_stamp(int);
void copy_data(st**);
st* search(st*);
void issue_book(st**);
void return_book(st**);
st* search_fun(int,char*,st*);

