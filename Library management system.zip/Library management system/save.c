#include "LMS.h"

void save(st*ptr)
{
FILE*fp = fopen("data.csv","w");
fprintf(fp,"Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
if(ptr != NULL)
{
    while(ptr != NULL)
    {
    fprintf(fp,"%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",ptr->Book_ID,ptr->Title,ptr->Author,ptr->Quantity,ptr->User_ID,ptr->User_name,
            ptr->Issue_date,ptr->Due_date,ptr->Return_date,ptr->Book_status,ptr->overdue_days,ptr->fine_amount);
    ptr = ptr->next;
    }
}
fclose(fp);


}

