#include "LMS.h"
st* search_fun(int,char*,st*);

st* search(st*ptr)
{
int op; 
do 
{
char detail[20];
st*temp = ptr;
printf("Serach by 1)By Book ID 2)By Title 3)By Author Name 4)By User ID 5)By User Name 6)Back to home menu\n");

if (scanf("%d", &op) != 1) 
        {
            // If it failed, clear the garbage characters from the buffer
            while (getchar() != '\n'); 
            op = -1; // Force an invalid option to trigger the default case safely
        }

st*found_ptr;
switch(op)
{
    case 1 : 
    {
    printf("Enter Book_ID\n");
    scanf(" %[^\n]",detail);
    found_ptr = search_fun(1,detail,temp);
    return found_ptr;
    break;
    }
    case 2 : 
    {
    printf("Enter Book Title\n");
    scanf(" %[^\n]",detail);
    found_ptr = search_fun(2,detail,temp);
    return found_ptr;
    break;
    }
    case 3 : 
    {
    printf("Enter Author\n");
    scanf(" %[^\n]",detail);
    found_ptr = search_fun(3,detail,temp);
    return found_ptr;
    break;
    }
    case 4 : 
    {
    printf("Enter User_ID\n");
    scanf(" %[^\n]",detail);
    found_ptr = search_fun(4,detail,temp);
    return found_ptr;
    break;
    }
    case 5 : 
    {
    printf("Enter User_name\n");
    scanf(" %[^\n]",detail);
    found_ptr = search_fun(4,detail,temp);
    return found_ptr;
    break;
    }
    case 6 : break;
    default : {printf("Invalid, try again"); break;}
}

}while(op!=6);

}


st* search_fun(int cat,char*book_detail,st*temp)
{
    int found_count=0; st*f_temp = NULL;  
switch(cat)
{
   
case 1 :
{
while(temp != NULL)
{
    if((strcmp(temp->Book_ID,book_detail)) == 0) 
    {
        
        printf("-------------------------------------------------------FOUND DATA---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",temp->Book_ID,temp->Title,temp->Author,temp->Quantity,temp->User_ID,temp->User_name,
            temp->Issue_date,temp->Due_date,temp->Return_date,temp->Book_status,temp->overdue_days,temp->fine_amount);
        found_count++;
        f_temp = temp;
        break;
    }
    else
    temp = temp->next;
}
break;
}
case 2 :
{
while(temp != NULL)
{
    if((strcmp(temp->Title,book_detail)) == 0) 
    {
        printf("-------------------------------------------------------FOUND DATA---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",temp->Book_ID,temp->Title,temp->Author,temp->Quantity,temp->User_ID,temp->User_name,
            temp->Issue_date,temp->Due_date,temp->Return_date,temp->Book_status,temp->overdue_days,temp->fine_amount);
        found_count++;
        f_temp = temp;
        break;
    }
    else
    temp = temp->next;
}
break;
}

case 3 :
{
while(temp != NULL)
{
    if((strcmp(temp->Author,book_detail)) == 0) 
    {
        printf("-------------------------------------------------------FOUND DATA---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",temp->Book_ID,temp->Title,temp->Author,temp->Quantity,temp->User_ID,temp->User_name,
            temp->Issue_date,temp->Due_date,temp->Return_date,temp->Book_status,temp->overdue_days,temp->fine_amount);
        found_count++;
        f_temp = temp;
        break;
    }
    else
    temp = temp->next;
}
break;
}
case 4 :
{
while(temp != NULL)
{
    if((strcmp(temp->User_ID,book_detail)) == 0) 
    {
        printf("-------------------------------------------------------FOUND DATA---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",temp->Book_ID,temp->Title,temp->Author,temp->Quantity,temp->User_ID,temp->User_name,
            temp->Issue_date,temp->Due_date,temp->Return_date,temp->Book_status,temp->overdue_days,temp->fine_amount);
        found_count++;
        f_temp = temp;
        break;
    }
    else
    temp = temp->next;
}
break;
}

case 5 :
{
while(temp != NULL)
{
    if((strcmp(temp->User_name,book_detail)) == 0) 
    {
        printf("-------------------------------------------------------FOUND DATA---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",temp->Book_ID,temp->Title,temp->Author,temp->Quantity,temp->User_ID,temp->User_name,
            temp->Issue_date,temp->Due_date,temp->Return_date,temp->Book_status,temp->overdue_days,temp->fine_amount);
        found_count++;
        f_temp = temp;
        break;
    }
    else
    temp = temp->next;
}
break;
}

}

if (found_count == 0)  
{
    printf("No data available\n"); 
    return NULL;
}
else return f_temp;

}

