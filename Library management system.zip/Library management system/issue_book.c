#include "LMS.h"

void issue_book(st**ptr)
{
    if ((*ptr)->Quantity > 0) 
    --((*ptr)->Quantity);

    printf("Enter the User ID\n"); scanf(" %[^\n]",(*ptr)->User_ID);
    printf("Enter the User Name\n"); scanf(" %[^\n]",(*ptr)->User_name);

    strcpy((*ptr)->Issue_date,time_stamp(0));
    strcpy((*ptr)->Due_date,time_stamp(7));

    strcpy((*ptr)->Book_status ,"Book issued");
}