#include "LMS.h"

void copy_data(st**ptr)
{
    
   st*temp=NULL;
 FILE*fp = fopen("data.csv","r");
 if (fp != NULL)
 {
    
 fscanf(fp, "%*[^\n]\n");   
 
 st*new = (st*) malloc(sizeof(st));
 new->next = NULL;
 
 while ((fscanf(fp," %[^,], %[^,], %[^,], %d, %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %d, %d",new->Book_ID,new->Title,new->Author,&new->Quantity,new->User_ID,new->User_name,
            new->Issue_date,new->Due_date,new->Return_date,new->Book_status,&new->overdue_days,&new->fine_amount)) == 12)


    {
       
         if (*ptr == NULL){
        *ptr = new; temp=*ptr;}
        
        else
            {
            
            while(temp->next != NULL) temp = temp->next;
            temp->next = new;
            }
                  
          
           
            st*new1 = (st*) malloc(sizeof(st));
            new1->next = NULL;

            new = new1;
    }
fclose(fp);
 }

 else return;
}
      