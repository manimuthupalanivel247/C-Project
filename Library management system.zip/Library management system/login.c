#include "LMS.h"

void signup(void);

void login()
{
    char username[20];
    char password[20];
    char username_stored[20];
    char password_stored[20];
    char op;

    repeat:
    printf("Enter username\n");
    scanf(" %[^\n]",username);
    printf("Enter Password\n");
    scanf(" %[^\n]",password);
    
    FILE*fp = fopen("login","r"); 
    if (fp == NULL) 
    {
        printf("username or password not found, please sign up\n");
        signup();
    }
    else 
    {
    fscanf(fp,"%s %s",username_stored,password_stored);
    if ((strcmp(username_stored,username) == 0) && (strcmp(password_stored,password) ==0))
    printf("Welcom to Library Management system\n");
    else
        {
        printf("Either user name or password incorrect. If want to sign up, press y/n\n"); 
        scanf(" %c",&op);
        if(op == 'y') signup();
        else goto repeat;
        }       
    }
    fclose(fp);
    
}


void signup(void)
{
    char username[20];
    char password[20];
    printf("Enter username\n");
    scanf(" %[^\n]",username);
    printf("Enter Password\n");
    scanf(" %[^\n]",password);
    FILE*fp = fopen("login","w");
    fprintf(fp,"%s %s",username,password);
    fclose(fp);
}