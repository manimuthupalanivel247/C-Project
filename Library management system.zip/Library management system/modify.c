#include "LMS.h"

void modify(st**ptr)
{
int op;
printf("*ptr = %p",*ptr);
if (*ptr != NULL)
{
do
{
  printf("Which data to be modified? 1) Book_ID 2) Title 3) Author 4) Quantity 5)Exit\n");
  if (scanf("%d", &op) != 1) 
        {
            // If it failed, clear the garbage characters from the buffer
            while (getchar() != '\n'); 
            op = -1; // Force an invalid option to trigger the default case safely
        }


switch(op)
{
case 1: {printf("Enter Book_ID\n");scanf(" %[^\n]",(*ptr)->Book_ID); break;}
case 2: {printf("Enter Title\n");scanf(" %[^\n]",(*ptr)->Title); pf break;}
case 3: {printf("Enter Author\n");scanf(" %[^\n]",(*ptr)->Author); break;}
case 4: {printf("Enter Quantity\n");scanf("%d",&(*ptr)->Quantity); break;}
case 5 : break;
default : {printf("Invalid option");break;}
}

}while(op!=5);

          printf("-------------------------------------------------------MODIFIED---------------------------------------------------------------\n");
        printf("Book_ID, Title, Author, Quantity, User_ID, User_Name, Issue_date, Due_Date, Return_date, Book_status, overdue_days, fine_amount\n");
        printf("%s, %s, %s, %d, %s, %s, %s, %s, %s, %s, %d, %d\n",(*ptr)->Book_ID,(*ptr)->Title,(*ptr)->Author,(*ptr)->Quantity,(*ptr)->User_ID,(*ptr)->User_name,
            (*ptr)->Issue_date,(*ptr)->Due_date,(*ptr)->Return_date,(*ptr)->Book_status,(*ptr)->overdue_days,(*ptr)->fine_amount);
}
else 
{
  printf("No data available\n"); 
  return;
}

}